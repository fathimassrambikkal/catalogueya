import React, { useEffect, useMemo, useState } from "react";
import Pusher from "pusher-js";
import { getCustomerNotifications } from "../api";

const API_BASE = "https://catalogueyanew.com.awu.zxu.temporary.site";

/* ---------------- NORMALIZER ---------------- */
function normalizeNotification(raw, index = 0) {
  if (!raw) return null;

  const title = raw.notification?.title ?? "Notification";
  const body = raw.notification?.body ?? "";
  const data = raw.data ?? {};

  const type =
    data.product_type === "low_stock"
      ? "lowStock"
      : data.product_type === "product"
      ? "promotions"
      : data.type || "main";

  return {
    id: `${type}-${index}-${title}`, // ✅ stable unique key
    name: title,
    preview: body,
    unread: 1,
    type,
    data,
    title,
    body,
  };
}

export default function Notifications() {
  const [activeView, setActiveView] = useState("main");
  const [loading, setLoading] = useState(true);

  const [notifications, setNotifications] = useState([]);
  const [promotions, setPromotions] = useState([]);
  const [lowStockItems, setLowStockItems] = useState([]);

  /* ---------------- USER MEMO ---------------- */
  const { token, userId, channelName } = useMemo(() => {
    const userRaw = localStorage.getItem("user");
    const token = localStorage.getItem("token");

    let user = null;
    try {
      user = userRaw ? JSON.parse(userRaw) : null;
    } catch {}

    const userId = user?.id;
    const userType = (user?.type || "User").toLowerCase();
    const channelName = userId ? `private-${userType}.${userId}` : null;

    return { token, userId, channelName };
  }, []);

  /* ---------------- FETCH NOTIFICATIONS ---------------- */
  useEffect(() => {
    const fetchNotifications = async () => {
      try {
        const res = await getCustomerNotifications();
        const all = res.data?.data || [];

        const normalized = all
          .map((n, i) => normalizeNotification(n, i))
          .filter(Boolean);

        setNotifications(normalized);

        setPromotions(
          normalized.filter((n) => n.type === "promotions")
        );

        setLowStockItems(
          normalized.filter((n) => n.type === "lowStock")
        );
      } catch (err) {
        console.error("❌ Notification fetch failed:", err);
      } finally {
        setLoading(false);
      }
    };

    fetchNotifications();
  }, []);

  /* ---------------- PUSHER REALTIME ---------------- */
  useEffect(() => {
    if (loading || !token || !channelName) return;

    Pusher.logToConsole = true;

    const pusher = new Pusher("a613271cbafcf4059d6b", {
      cluster: "ap2",
      authEndpoint: `${API_BASE}/broadcasting/auth`,
      auth: {
        headers: {
          Authorization: `Bearer ${token}`,
          Accept: "application/json",
        },
      },
      enabledTransports: ["ws", "wss"],
      forceTLS: true,
    });

    const channel = pusher.subscribe(channelName);

    channel.bind("dashboard.notification", (payload) => {
      const normalized = normalizeNotification(payload, Date.now());
      if (!normalized) return;

      setNotifications((prev) =>
        prev.some((x) => x.id === normalized.id)
          ? prev
          : [normalized, ...prev]
      );

      if (normalized.type === "promotions") {
        setPromotions((prev) =>
          prev.some((x) => x.id === normalized.id)
            ? prev
            : [normalized, ...prev]
        );
      }

      if (normalized.type === "lowStock") {
        setLowStockItems((prev) =>
          prev.some((x) => x.id === normalized.id)
            ? prev
            : [normalized, ...prev]
        );
      }
    });

    return () => {
      channel.unbind_all();
      pusher.unsubscribe(channelName);
      pusher.disconnect();
    };
  }, [loading, token, channelName]);

  /* ---------------- CLICK = MARK AS READ ---------------- */
  const handleNotificationClick = (n) => {
    setNotifications((prev) =>
      prev.map((x) => (x.id === n.id ? { ...x, unread: 0 } : x))
    );
    setActiveView(n.type);
  };

  if (loading) {
    return <div className="p-6 text-center text-gray-500">Loading notifications...</div>;
  }

  /* ---------------- MAIN VIEW ---------------- */
  const renderMainView = () => (
    <div className="min-h-screen bg-gradient-to-br from-blue-50/50 via-white to-blue-50/30 p-4 sm:p-6">
      <h1 className="text-lg sm:text-2xl font-bold text-gray-900 mb-6">
        Notifications
      </h1>

      <div className="space-y-3">
        {notifications.map((n) => (
          <div
            key={n.id}
            onClick={() => handleNotificationClick(n)}
            className="flex items-center p-4 rounded-xl bg-white cursor-pointer"
          >
            <div className="mr-4 font-bold">
              {n.unread > 0 ? n.unread : ""}
            </div>
            <div>
              <h3 className="font-semibold">{n.name}</h3>
              <p className="text-sm text-gray-600">{n.preview}</p>
            </div>
          </div>
        ))}
      </div>
    </div>
  );

  const renderPromotions = () => (
    <div className="min-h-screen p-4">
      <button onClick={() => setActiveView("main")}>←</button>
      <h1 className="text-xl font-bold mb-4">Promotions</h1>
      {promotions.map((p) => (
        <div key={p.id} className="p-3 bg-white rounded mb-2">
          <div className="font-semibold">{p.name}</div>
          <div className="text-sm text-gray-600">{p.preview}</div>
        </div>
      ))}
    </div>
  );

  const renderLowStock = () => (
    <div className="min-h-screen p-4">
      <button onClick={() => setActiveView("main")}>←</button>
      <h1 className="text-xl font-bold mb-4">Low In Stock</h1>
      {lowStockItems.map((i) => (
        <div key={i.id} className="p-3 bg-white rounded mb-2">
          <div className="font-semibold">{i.name}</div>
          <div className="text-sm text-gray-600">{i.preview}</div>
        </div>
      ))}
    </div>
  );

  return activeView === "promotions"
    ? renderPromotions()
    : activeView === "lowStock"
    ? renderLowStock()
    : renderMainView();
}
