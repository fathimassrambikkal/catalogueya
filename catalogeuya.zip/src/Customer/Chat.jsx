import React, { useEffect, useRef, useState, useCallback } from "react";
import Pusher from "pusher-js";
import { useParams, useNavigate, useLocation } from "react-router-dom";

import {
  getCustomerConversation,
  sendCustomerMessage,
  sendCustomerTyping,
  markCustomerConversationRead,
} from "../api";

import ChatHeader from "./ChatHeader";
import MessageList from "./MessageList";
import ChatInput from "./ChatInput";

Pusher.logToConsole = true;

const API_BASE = "https://catalogueyanew.com.awu.zxu.temporary.site";

export default function Chat() {
  const { conversationId } = useParams();
  const navigate = useNavigate();
  const location = useLocation();

  const [conversation, setConversation] = useState(
    location.state?.conversation || null
  );
  const [messages, setMessages] = useState(location.state?.messages || []);
  const [input, setInput] = useState("");
  const [files, setFiles] = useState([]);
  const [loading, setLoading] = useState(false);

  const typingTimeoutRef = useRef(null);

  const currentUserRaw = localStorage.getItem("user");
  const token = localStorage.getItem("token");

  let currentUser = null;
  try {
    currentUser = currentUserRaw ? JSON.parse(currentUserRaw) : null;
  } catch (e) {
    console.error("❌ Failed to parse currentUser from localStorage:", e);
  }

  const currentUserId = currentUser?.id;

  // ✅ IMPORTANT: dynamic type support (User / Company / Customer...)
  const currentUserType = (currentUser?.type || "User").toLowerCase();

  // ✅ Private channel name (must match Laravel PrivateChannel)
  const channelName = currentUserId
    ? `private-${currentUserType}.${currentUserId}`
    : null;

  // 🔥 INSTANT UI FALLBACK - NO LOADER BLOCK
  if (!conversation) {
    return (
      <div className="flex flex-col h-screen bg-gradient-to-b from-blue-50 to-white">
        <div className="p-4 border-b border-gray-200 bg-white">
          <button
            onClick={() => navigate(-1)}
            className="p-2 hover:bg-gray-100 rounded-full transition-colors"
          >
            <svg
              className="w-5 h-5 text-gray-600"
              fill="none"
              stroke="currentColor"
              viewBox="0 0 24 24"
            >
              <path
                strokeLinecap="round"
                strokeLinejoin="round"
                strokeWidth={2}
                d="M15 19l-7-7 7-7"
              />
            </svg>
          </button>
        </div>

        <div className="flex-1 flex items-center justify-center">
          <div className="text-center">
            <div className="w-12 h-12 border-3 border-blue-500/20 border-t-blue-500 rounded-full animate-spin mb-3"></div>
            <p className="text-gray-500 text-sm">Loading chat...</p>
          </div>
        </div>
        <div className="p-4 border-t border-gray-200 bg-white"></div>
      </div>
    );
  }

  // 🔹 BACKGROUND FETCH ONLY (NO UI BLOCKING)
  useEffect(() => {
    if (!conversationId) return;

    setLoading(true);

    getCustomerConversation(conversationId)
      .then((res) => {
        setConversation(res.data.conversation);
        setMessages(res.data.messages || []);
        markCustomerConversationRead(conversationId);
      })
      .catch((err) => {
        console.error("❌ Conversation sync failed:", err);
      })
      .finally(() => setLoading(false));
  }, [conversationId]);

  // 🔥 PUSHER DIAGNOSTIC VERSION
  useEffect(() => {
    if (!currentUserId) {
      console.warn("⚠️ No currentUserId. localStorage user:", currentUser);
      return;
    }
    if (!token) {
      console.warn("⚠️ No token found in localStorage. Auth will fail.");
    }
    if (!channelName) {
      console.warn("⚠️ No channelName computed.");
      return;
    }

    console.log("================ PUSHER DEBUG START ================");
    console.log("currentUser:", currentUser);
    console.log("token exists:", Boolean(token));
    console.log("computed channelName:", channelName);
    console.log("route conversationId:", conversationId);
    console.log("authEndpoint:", `${API_BASE}/broadcasting/auth`);
    console.log("====================================================");

    const pusher = new Pusher("a613271cbafcf4059d6b", {
      cluster: "ap2",
      authEndpoint: `${API_BASE}/broadcasting/auth`,
      auth: {
        headers: {
          Authorization: `Bearer ${token}`,
          Accept: "application/json",
        },
      },
      enabledTransports: ["ws", "wss"],
      forceTLS: true,
    });

    // Connection diagnostics
    pusher.connection.bind("connecting", () =>
      console.log("🟡 Pusher connecting...")
    );
    pusher.connection.bind("connected", () =>
      console.log("✅ Pusher connected")
    );
    pusher.connection.bind("disconnected", () =>
      console.log("🟠 Pusher disconnected")
    );
    pusher.connection.bind("error", (err) =>
      console.error("❌ Pusher connection error:", err)
    );

    const channel = pusher.subscribe(channelName);

    channel.bind("pusher:subscription_succeeded", () => {
      console.log("✅ Subscribed OK:", channelName);
    });

    channel.bind("pusher:subscription_error", (status) => {
      console.error("❌ Subscription error:", status, "channel:", channelName);
    });

    // 🔥 Catch ANY event name that arrives
    channel.bind_global((event, data) => {
      console.log("🌍 GLOBAL EVENT:", event, data);

      // If payload includes message, show why it is/ isn't added
      if (data?.message) {
        const incomingConvId = data?.conversation_id;
        console.log(
          "🔎 incoming conversation_id:",
          incomingConvId,
          "route:",
          conversationId
        );

        if (Number(incomingConvId) !== Number(conversationId)) {
          console.log("⛔ Ignored: conversation_id mismatch");
          return;
        }

        const msg = data.message;
        setMessages((prev) => {
          if (prev.some((m) => m.id === msg.id)) {
            console.log("↩️ Ignored: duplicate message id", msg.id);
            return prev;
          }
          console.log("➕ Added message id:", msg.id);
          return [...prev, msg];
        });
      }
    });

    // Also bind explicit names (in case you prefer specific binding)
    channel.bind("message.sent", (data) => {
      console.log("📩 bound message.sent:", data);
    });
    channel.bind("App\\Events\\MessageSent", (data) => {
      console.log("📩 bound App\\Events\\MessageSent:", data);
    });

    return () => {
      console.log("🧹 Cleanup pusher:", channelName);
      try {
        channel.unbind_all();
      } catch {}
      try {
        pusher.unsubscribe(channelName);
      } catch {}
      try {
        pusher.disconnect();
      } catch {}
    };
  }, [currentUserId, channelName, token, conversationId]); // note: channelName already depends on type+id

  // 🔹 REMOVE FILE FUNCTION
  const removeFile = useCallback((id) => {
    setFiles((prev) => {
      const file = prev.find((f) => f.id === id);
      if (file?.localUrl) URL.revokeObjectURL(file.localUrl);
      return prev.filter((f) => f.id !== id);
    });
  }, []);

  // 🔹 FILE CHANGE FUNCTION
  const handleFileChange = useCallback((e) => {
    const selectedFiles = Array.from(e.target.files);
    if (selectedFiles.length === 0) return;

    const previews = selectedFiles.map((file) => ({
      id: `local-${crypto.randomUUID()}`,
      file,
      localUrl: URL.createObjectURL(file),
      type: file.type,
    }));

    setFiles((prev) => [...prev, ...previews]);
  }, []);

  // 🔹 SEND MESSAGE - INSTANT
  const handleSend = async () => {
    if (!input.trim() && files.length === 0) return;

    const tempId = `temp-${Date.now()}`;

    const optimistic = {
      id: tempId,
      sender_id: currentUserId,
      body: input,
      attachments: files.map((f) => ({
        id: f.id,
        localUrl: f.localUrl,
        type: f.type,
      })),
      created_at: new Date().toISOString(),
      pending: true,
      delivered_at: null,
      read_at: null,
    };

    setMessages((prev) => [...prev, optimistic]);
    setInput("");
    setFiles([]);

    const formData = new FormData();
    if (input.trim()) formData.append("body", input);
    files.forEach((f) => formData.append("attachments[]", f.file));

    try {
      const res = await sendCustomerMessage(conversationId, formData);
      setMessages((prev) =>
        prev.map((msg) =>
          msg.id === tempId
            ? { ...res.data.message, delivered_at: new Date().toISOString() }
            : msg
        )
      );
    } catch (err) {
      console.error("❌ Send failed:", err);
      setMessages((prev) =>
        prev.map((msg) =>
          msg.id === tempId ? { ...msg, pending: false, failed: true } : msg
        )
      );
    }
  };

  // 🔹 TYPING
  const handleTyping = useCallback(
    (e) => {
      setInput(e.target.value);
      sendCustomerTyping(conversationId, true);

      clearTimeout(typingTimeoutRef.current);
      typingTimeoutRef.current = setTimeout(() => {
        sendCustomerTyping(conversationId, false);
      }, 800);
    },
    [conversationId]
  );

  // 🔹 RENDER ATTACHMENT
  const renderAttachment = useCallback((att) => {
    const src = att.path || att.localUrl;
    if (!src) return null;

    if (att.type?.startsWith("image")) {
      return (
        <div className="relative group">
          <img
            src={src}
            alt="Attachment"
            className="max-w-xs rounded-xl border border-white/20 shadow-lg transition-transform duration-300 group-hover:scale-[1.02]"
            loading="lazy"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-black/10 to-transparent rounded-xl opacity-0 group-hover:opacity-100 transition-opacity duration-300" />
        </div>
      );
    }

    if (att.type?.startsWith("video")) {
      return (
        <div className="relative group">
          <video controls className="max-w-xs rounded-xl border border-white/20 shadow-lg">
            <source src={src} />
          </video>
        </div>
      );
    }

    return (
      <a
        href={src}
        target="_blank"
        rel="noreferrer"
        className="inline-flex items-center gap-2 px-4 py-2 bg-white/80 backdrop-blur-sm rounded-xl border border-gray-200/60 hover:bg-white transition-colors duration-200"
      >
        <svg className="w-5 h-5 text-blue-600" fill="currentColor" viewBox="0 0 24 24">
          <path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8l-6-6zm2 18H6V4h7v5h5v11z" />
        </svg>
        <span className="text-sm font-medium text-gray-700">Download file</span>
      </a>
    );
  }, []);

  const formatTime = useCallback(
    (d) =>
      new Date(d).toLocaleTimeString([], {
        hour: "numeric",
        minute: "2-digit",
        hour12: true,
      }),
    []
  );

  return (
    <div className="flex flex-col h-screen bg-gradient-to-b from-blue-50 via-white to-white">
      <ChatHeader
        conversation={conversation}
        navigate={navigate}
        API_BASE={API_BASE}
        onBack={() => navigate(-1)}
      />

      {loading && (
        <div className="absolute top-16 left-0 right-0 z-10">
          <div className="bg-blue-500/10 text-blue-600 text-xs py-1 text-center">
            <div className="inline-flex items-center gap-1">
              <div className="w-2 h-2 rounded-full bg-blue-500 animate-pulse"></div>
              Syncing...
            </div>
          </div>
        </div>
      )}

      <MessageList
        messages={messages}
        currentUserId={currentUserId}
        renderAttachment={renderAttachment}
        formatTime={formatTime}
      />

      <ChatInput
        input={input}
        files={files}
        onTyping={handleTyping}
        onSend={handleSend}
        onFileChange={handleFileChange}
        removeFile={removeFile}
      />
    </div>
  );
}