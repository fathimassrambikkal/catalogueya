import React, { memo } from "react";

// Close icon (same SVG)
const CloseIcon = ({ className = "" }) => (
  <svg
    className={className}
    width="16"
    height="16"
    viewBox="0 0 24 24"
    fill="none"
    stroke="currentColor"
    strokeWidth="2.5"
    strokeLinecap="round"
    strokeLinejoin="round"
  >
    <path d="M18 6L6 18M6 6l12 12" />
  </svg>
);

// Star icon (same SVG + behavior)
const StarIcon = ({ filled, className = "" }) => (
  <svg
    className={className}
    width="16"
    height="16"
    viewBox="0 0 576 512"
    fill={filled ? "currentColor" : "none"}
    stroke={filled ? "currentColor" : "#9CA3AF"}
    strokeWidth="30"
  >
    <path d="M316.9 18C311.6 7 300.4 0 288.1 0s-23.4 7-28.8 18L195 150.3 51.4 171.5c-12 1.8-22 10.2-25.7 21.7s-.7 24.2 7.9 32.7L137.8 329 113.2 474.7c-2 12 3 24.2 12.9 31.3s23 8 33.8 2.3l128.3-68.5 128.3 68.5c10.8 5.7 23.9 4.9 33.8-2.3s14.9-19.3 12.9-31.3L438.5 329 542.7 225.9c8.6-8.5 11.7-21.2 7.9-32.7s-13.7-19.9-25.7-21.7L381.2 150.3 316.9 18z" />
  </svg>
);

// Rating safety helper (same logic)
const getSafeRating = (value) => {
  const num = Number(value);
  if (Number.isNaN(num) || num < 0) return 0;
  if (num > 5) return 5;
  return num;
};

const ReviewModal = memo(function ReviewModal({
  reviews,
  reviewName,
  reviewText,
  reviewRating,
  setReviewName,
  setReviewText,
  setReviewRating,
  onClose,
  onSubmit,
}) {
  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center bg-black/20 backdrop-blur-lg px-4 animate-fade-in"
      onClick={onClose}
    >
      <div
        className="
          w-full max-w-lg rounded-3xl
          bg-white/55 backdrop-blur-2xl
          border border-white/30
          shadow-[0_12px_32px_rgba(0,0,0,0.12)]
          p-6 space-y-6
          animate-slide-up
        "
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="flex items-center justify-between">
          <h3 className="text-lg font-semibold text-gray-900">
            Customer Reviews
          </h3>
          <button
            onClick={onClose}
            className="
              h-8 w-8 flex items-center justify-center rounded-full
              bg-white/60 text-gray-500 hover:bg-white
              transition active:scale-95
            "
          >
            <CloseIcon className="w-4 h-4" />
          </button>
        </div>

        {/* Reviews list */}
        <div className="max-h-[40vh] overflow-y-auto space-y-3 pr-1">
          {reviews.length > 0 ? (
            reviews.map((rev) => (
              <div
                key={rev.id}
                className="border border-white/40 rounded-2xl p-4 bg-white/60"
              >
                <div className="flex justify-between mb-1">
                  <span className="font-semibold text-gray-800">
                    {rev.name}
                  </span>
                  <span className="text-gray-500 text-xs">
                    {rev.date}
                  </span>
                </div>

                <div className="flex items-center gap-1 mb-1">
                  {Array.from({ length: 5 }).map((_, i) => (
                    <StarIcon
                      key={i}
                      filled={i < getSafeRating(rev.rating)}
                      className={`w-4 h-4 ${
                        i < getSafeRating(rev.rating)
                          ? "text-gray-950"
                          : "text-gray-400"
                      }`}
                    />
                  ))}
                </div>

                <p className="text-gray-700 text-sm">{rev.comment}</p>
              </div>
            ))
          ) : (
            <p className="text-gray-500 text-center text-sm">
              No reviews yet – be the first to review!
            </p>
          )}
        </div>

        {/* Form */}
        <div className="space-y-3 pt-2 border-t border-white/40">
          <h3 className="text-md font-semibold text-gray-900">
            Write a Review
          </h3>

          {/* Name */}
          <div className="space-y-1.5">
            <label className="text-xs font-medium text-gray-700">
              Your Name
            </label>
            <input
              type="text"
              value={reviewName}
              onChange={(e) => setReviewName(e.target.value)}
              placeholder="Your Name"
              className="
                w-full rounded-xl px-3 py-2.5 text-sm
                bg-white/60 border border-white/20
                placeholder:text-gray-400
                focus:outline-none focus:ring-2 focus:ring-gray-900/40
              "
            />
          </div>

          {/* Rating */}
          <div className="space-y-1.5">
            <label className="text-xs font-medium text-gray-700">
              Rating
            </label>
            <div
              className="
                flex items-center justify-center gap-3 px-4 py-2.5
                rounded-xl bg-white/50 border border-white/20
              "
            >
              {Array.from({ length: 5 }).map((_, i) => (
                <button
                  key={i}
                  type="button"
                  onClick={() => setReviewRating(i + 1)}
                  className="transition-transform duration-150 active:scale-95"
                >
                  <StarIcon
                    filled={i < reviewRating}
                    className="w-6 h-6"
                  />
                </button>
              ))}
            </div>
          </div>

          {/* Comment */}
          <div className="space-y-1.5">
            <label className="text-xs font-medium text-gray-700">
              Your Review
            </label>
            <textarea
              value={reviewText}
              onChange={(e) => setReviewText(e.target.value)}
              rows="4"
              placeholder="Share your thoughts about this product..."
              className="
                w-full rounded-xl px-3 py-2.5 text-sm
                bg-white/60 border border-white/20
                placeholder:text-gray-400
                resize-none
                focus:outline-none focus:ring-2 focus:ring-gray-900/40
              "
            />
          </div>

          {/* Actions */}
          <div className="flex justify-end gap-3 pt-1">
            <button
              onClick={onClose}
              className="
                px-4 py-2 text-sm rounded-xl
                bg-white/70 text-gray-700
                hover:bg-white transition
                active:scale-95
              "
            >
              Cancel
            </button>
            <button
              onClick={onSubmit}
              disabled={!reviewText || !reviewName || reviewRating === 0}
              className={`
                px-4 py-2 text-sm rounded-xl text-white
                active:scale-95
                ${
                  reviewText && reviewName && reviewRating
                    ? "bg-gray-900 hover:bg-gray-800"
                    : "bg-gray-400 cursor-not-allowed"
                }
              `}
            >
              Submit
            </button>
          </div>
        </div>
      </div>
    </div>
  );
});

export default ReviewModal;
