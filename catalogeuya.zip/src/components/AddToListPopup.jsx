import { useEffect, useMemo, useState } from "react";
import { useDispatch, useSelector } from "react-redux";
import {
  closeListPopup,
  setFavouriteLists,
} from "../store/favouritesSlice";
import {
  getFavoriteGroups,
  addProductToFavorite,
} from "../api";

// ✅ normalize backend response
const normalizeGroups = (response) => {
  return Array.isArray(response?.data?.groups)
    ? response.data.groups
    : [];
};

export default function AddToListPopup() {
  const dispatch = useDispatch();

  const { showListPopup, pendingProduct, lists } = useSelector(
    (state) => state.favourites
  );
  const isLoggedIn = useSelector((state) => !!state.auth.user);

  const [selectedList, setSelectedList] = useState(null);
  const [sending, setSending] = useState(false);

  // ✅ Normalize redux lists safely
  const safeLists = useMemo(() => {
    if (Array.isArray(lists)) return lists;
    if (Array.isArray(lists?.groups)) return lists.groups;
    return [];
  }, [lists]);

  // ================= LOAD GROUPS FROM API =================
  useEffect(() => {
    if (!showListPopup || !isLoggedIn) return;

    // reset selection every popup open
    setSelectedList(null);

    getFavoriteGroups()
      .then((res) => {
        const groups = normalizeGroups(res);
        dispatch(setFavouriteLists(groups));
      })
      .catch((err) =>
        console.error("❌ Failed to load favourite groups", err)
      );
  }, [showListPopup, isLoggedIn, dispatch]);

  // 🚫 render guard AFTER hooks
  if (!isLoggedIn || !showListPopup || !pendingProduct) return null;

  // ================= SEND PRODUCT =================
  const handleSend = async () => {
    if (!selectedList) return;

    try {
      setSending(true);

      await addProductToFavorite(
        pendingProduct.id,
        selectedList.id
      );

      // 🔁 re-fetch groups so Redux stays in sync
      const res = await getFavoriteGroups();
      const groups = normalizeGroups(res);

      dispatch(setFavouriteLists(groups));
      dispatch(closeListPopup());
    } catch (err) {
      console.error("❌ Add to favourite failed", err);
    } finally {
      setSending(false);
    }
  };

  // ================= UI =================
  return (
    <div className="fixed top-6 left-1/2 -translate-x-1/2 z-50 w-[360px]">
      <div
        className="
          backdrop-blur-2xl bg-white/75
          border border-white/40
          rounded-3xl shadow-[0_25px_60px_rgba(0,0,0,0.18)]
          p-5
        "
      >
        <h3 className="text-sm font-semibold text-gray-900 mb-4">
          Add to Favourite List
        </h3>

        {/* LISTS */}
        <div className="space-y-2 max-h-56 overflow-y-auto">
          {safeLists.length === 0 && (
            <p className="text-sm text-gray-500 text-center py-6">
              No lists found
            </p>
          )}

          {safeLists.map((list) => (
            <button
              key={list.id}
              onClick={() => setSelectedList(list)}
              className={`
                w-full px-4 py-2.5 rounded-xl text-left
                border transition
                ${
                  selectedList?.id === list.id
                    ? "bg-blue-50 border-blue-400 text-blue-700"
                    : "bg-white/60 border-gray-200 hover:bg-blue-50"
                }
              `}
            >
              <span className="text-sm font-medium">
                {list.name}
              </span>
            </button>
          ))}
        </div>

        {/* ACTIONS */}
        <div className="flex gap-3 mt-5">
          <button
            onClick={() => dispatch(closeListPopup())}
            className="flex-1 py-2.5 rounded-xl bg-gray-100 hover:bg-gray-200 text-sm"
          >
            Cancel
          </button>

          <button
            onClick={handleSend}
            disabled={!selectedList || sending}
            className="
              flex-1 py-2.5 rounded-xl
              bg-blue-500 text-white text-sm font-medium
              hover:bg-blue-600 transition
              disabled:opacity-50 disabled:cursor-not-allowed
            "
          >
            {sending ? "Sending..." : "Send"}
          </button>
        </div>
      </div>
    </div>
  );
}
