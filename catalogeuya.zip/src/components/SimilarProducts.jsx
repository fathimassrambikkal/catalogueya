// src/components/SimilarProducts.jsx
import React, { memo } from "react";
import { useNavigate } from "react-router-dom";

const HeartIcon = ({ filled, className = "" }) => (
  <svg
    viewBox="0 0 24 24"
    className={className}
    fill={filled ? "currentColor" : "none"}
    stroke={filled ? "none" : "currentColor"}
    strokeWidth="2"
  >
    <path d="M20.84 4.61a5.5 5.5 0 0 0-7.78 0L12 5.67l-1.06-1.06a5.5 5.5 0 0 0-7.78 7.78L12 21.23l7.78-7.78a5.5 5.5 0 0 0 0-7.78z" />
  </svg>
);

const SimilarProducts = memo(function SimilarProducts({
  products,
  favourites,
  toggleFavourite,
}) {
  const navigate = useNavigate();

  if (!products || products.length === 0) return null;

  return (
    <section className="max-w-6xl mx-auto px-6 py-20">
      <h2 className="text-3xl font-light text-gray-900 mb-12">
        Similar Products
      </h2>

      <div className="grid grid-cols-2 sm:grid-cols-2 lg:grid-cols-4 gap-6">
        {products.map((sp) => {
          const isFav = favourites.some((f) => f.id === sp.id);

          return (
            <div
              key={sp.id}
              onClick={() => navigate(`/newarrivalprofile/${sp.id}`)}
              className="relative bg-white rounded-2xl border border-gray-100 shadow-sm hover:shadow-md transition cursor-pointer hover:scale-[1.03]"
            >
              <button
                onClick={(e) => {
                  e.stopPropagation();
                  toggleFavourite(sp);
                }}
                className={`absolute top-3 right-3 z-20 p-2 rounded-full bg-white border shadow-sm
                  ${isFav ? "text-red-500" : "text-gray-500"}`}
              >
                <HeartIcon filled={isFav} className="w-3 h-3" />
              </button>

              <div className="w-full h-[220px] overflow-hidden rounded-t-2xl">
                <img
                  src={sp.image}
                  alt={sp.name}
                  className="w-full h-full object-cover transition-transform duration-500 hover:scale-105"
                  loading="lazy"
                />
              </div>

              <div className="p-4">
                <h3 className="text-sm font-medium truncate mb-1">
                  {sp.name}
                </h3>
                <span className="text-sm font-semibold">QAR {sp.price}</span>
              </div>
            </div>
          );
        })}
      </div>
    </section>
  );
});

export default SimilarProducts;
