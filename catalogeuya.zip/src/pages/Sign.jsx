import React, { useState, useEffect } from "react";
import { Link, useNavigate } from "react-router-dom";

import { api, loginCustomer,  loginCompany,createCustomerConversation } from "../api";
import { useDispatch, useSelector } from "react-redux";
import { loginSuccess, logout as logoutAction } from "../store/authSlice";
import logo from "../assets/logo.png";
import { useLocation } from "react-router-dom";


// Modern Glassmorphism Alert Component - CENTERED ONLY
const ModernAlert = ({ message, show, type = "success" }) => {
  if (!show) return null;

  const alertConfig = {
    success: {
      bg: "bg-gradient-to-r from-green-500 to-emerald-500",
      icon: (
        <svg className="w-8 h-8" fill="none" stroke="currentColor" viewBox="0 0 24 24">
          <path 
            strokeLinecap="round" 
            strokeLinejoin="round" 
            strokeWidth="2" 
            d="M5 13l4 4L19 7"
          ></path>
        </svg>
      ),
      title: "Success!"
    },
    info: {
      bg: "bg-gradient-to-r from-green-500 to-emerald-500",
      icon: (
        <svg className="w-8 h-8" fill="none" stroke="currentColor" viewBox="0 0 24 24">
          <path 
            strokeLinecap="round" 
            strokeLinejoin="round" 
            strokeWidth="2" 
            d="M5 13l4 4L19 7"
          ></path>
        </svg>
      ),
      title: "Success!"
    }
  };

  const config = alertConfig[type];

  return (
    <div className="fixed inset-0 flex items-center justify-center z-50">
      <div className="bg-white/90 backdrop-blur-xl rounded-2xl border border-white/20 shadow-2xl p-6 max-w-sm w-full mx-4 animate-scale-in">
        <div className="flex flex-col items-center text-center space-y-4">
          {/* Animated Icon */}
          <div className="relative">
            <div className={`w-16 h-16 ${config.bg} rounded-2xl flex items-center justify-center shadow-lg text-white`}>
              {config.icon}
            </div>
            {/* Pulsing Effect */}
            <div className="absolute inset-0 rounded-2xl bg-current opacity-20 animate-ping"></div>
          </div>
          
          <div className="flex-1">
            <h3 className="text-xl font-bold text-gray-800 mb-2">
              {config.title}
            </h3>
            <p className="text-gray-700 font-medium">{message}</p>
          </div>
        </div>
      </div>
    </div>
  );
};

// Welcome Page Component - CLEAN MODERN THEME
const WelcomePage = ({ user, userType, onGoToDashboard }) => {
  const navigate = useNavigate();
  const userName = user?.name || user?.email?.split('@')[0] || 'User';
  
  return (
    <div className="fixed inset-0 bg-gradient-to-br from-gray-50 to-blue-50/30 flex items-center justify-center z-50 p-4 overflow-x-hidden">
      <div className="bg-white/80 backdrop-blur-xl rounded-3xl border border-white/20 shadow-2xl p-4 sm:p-6 md:p-8 w-[95%] max-w-md animate-scale-in">
        
        {/* Logo */}
        <div className="flex justify-center mb-8">
        <Link
          to="/"
          className="hover:opacity-80 transition-all duration-300 transform hover:scale-105"
            >
          <img 
            src={logo} 
            alt="Home" 
            className="h-12 w-auto"
          />
        </Link>
      </div>


        {/* Welcome Header */}
        <div className="text-center mb-8">
          <h1 className="text-xl md:text-2xl lg:text-3xl font-bold text-gray-800 mb-3">
            Welcome
          </h1>
        </div>

        {/* User Info Card */}
        <div className="bg-gradient-to-r from-blue-50 to-cyan-50 rounded-2xl border border-blue-200/50 p-5 mb-8 backdrop-blur-sm">
          <div className="flex items-center justify-center space-x-4">
            <div className="w-12 h-12 bg-white rounded-full flex items-center justify-center shadow-sm border border-blue-200">
              <svg className="w-6 h-6 text-blue-500" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z"></path>
              </svg>
            </div>
            <div className="text-left">
              <p className="text-base font-medium text-gray-700">{user?.email}</p>
              <p className="text-sm text-gray-500">Active session</p>
            </div>
          </div>
        </div>

        {/* Action Buttons */}
        <div className="space-y-4">
          <button
            onClick={onGoToDashboard}
            className="w-full bg-gradient-to-r from-blue-500 to-cyan-500 text-white py-4 rounded-2xl text-lg font-semibold hover:from-blue-600 hover:to-cyan-600 transition-all duration-300 transform hover:scale-[1.02] shadow-lg hover:shadow-xl flex items-center justify-center space-x-3"
          >
            <svg className="w-6 h-6 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M3 12l2-2m0 0l7-7 7 7M5 10v10a1 1 0 001 1h3m10-11l2 2m-2-2v10a1 1 0 01-1 1h-3m-6 0a1 1 0 001-1v-4a1 1 0 011-1h2a1 1 0 011 1v4a1 1 0 001 1m-6 0h6"></path>
            </svg>
            <span className="text-lg">Go to Dashboard</span>
          </button>
          
<button
  onClick={() => navigate("/")}
  className="
    w-full
    relative
    overflow-hidden
    bg-white/70
    backdrop-blur-xl
    border
    border-white/40
    text-blue-600
    py-4
    rounded-2xl
    text-lg
    font-semibold
    shadow-[0_8px_30px_rgba(0,0,0,0.08)]
    hover:shadow-[0_10px_32px_rgba(0,0,0,0.12)]
    transition-all
    duration-300
    transform
    hover:scale-[1.02]
    active:scale-[0.98]
    group
  "
>
  {/* subtle white highlight only */}
  <span className="absolute inset-0 bg-white/10 opacity-0 group-hover:opacity-100 transition-opacity duration-300 rounded-2xl"></span>

  <span className="relative flex items-center justify-center gap-3">
    {/* Search Icon */}
    <svg
      className="w-6 h-6 text-blue-500"
      fill="none"
      stroke="currentColor"
      strokeWidth="2.2"
      viewBox="0 0 24 24"
    >
      <circle cx="11" cy="11" r="7" />
      <path
        strokeLinecap="round"
        strokeLinejoin="round"
        d="M21 21l-4.3-4.3"
      />
    </svg>

    <span className="tracking-wide">
      Discover Catalogueya
    </span>
  </span>
</button>



        </div>
      </div>
    </div>
  );
};

export default function Sign() {
  const navigate = useNavigate();
  const dispatch = useDispatch();
  const auth = useSelector((state) => state.auth);
  const [showPassword, setShowPassword] = useState(false);
const [showCompanyPassword, setShowCompanyPassword] = useState(false);
  const [isRegistered, setIsRegistered] = useState(false);
  const [loginType, setLoginType] = useState("customer");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [companyEmail, setCompanyEmail] = useState("");
  const [companyPassword, setCompanyPassword] = useState("");
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");
  const location = useLocation();
const redirectPath =
  new URLSearchParams(location.search).get("redirect");

  // Alert state
  const [showAlert, setShowAlert] = useState(false);
  const [alertMessage, setAlertMessage] = useState("");
  const [alertType, setAlertType] = useState("success");

  // Welcome page state
  const [showWelcome, setShowWelcome] = useState(false);


useEffect(() => {
  if (auth.userType === "customer") {
    import("../pages/CustomerLogin");
  }

  if (auth.userType === "company") {
    import("../pages/CompanyDashboard");
  }
}, [auth.userType]);

 
 

  useEffect(() => {
    // Check URL parameters for registration success
    const urlParams = new URLSearchParams(window.location.search);
    const fromRegistration = urlParams.get("registered") === "true";

    if (fromRegistration) {
      setIsRegistered(true);
    }
  }, []);

  const showModernAlert = (message, type = "success") => {
    setAlertMessage(message);
    setAlertType(type);
    setShowAlert(true);

    // Auto hide after 2 seconds
    setTimeout(() => {
      setShowAlert(false);
    }, 2000);
  };

  // REAL CUSTOMER LOGIN with cookie-based auth


// REAL CUSTOMER LOGIN with TOKEN-based auth
const handleCustomerLogin = async (e) => {
  e.preventDefault();
  if (loginType !== "customer") return;

  setLoading(true);
  setError("");

  try {
    console.log("📤 Sending login request...", {
      email: email.trim(),
      password: password.trim(),
    });

    // 🔐 LOGIN API CALL
    const res = await loginCustomer(
      email.trim(),
      password.trim()
    );

    console.log("📥 FULL RESPONSE:", res);
    console.log("📥 RESPONSE DATA:", res.data);
    console.log(
      "📥 RESPONSE DATA STRUCTURE:",
      JSON.stringify(res.data, null, 2)
    );

    // 🔎 EXTRACT TOKEN (support multiple backend formats)
    const token =
      res.data?.token ||
      res.data?.access_token ||
      res.data?.data?.token ||
      res.data?.authorization?.token;

    console.log("🔍 Token extracted:", token);

    if (!token) {
      throw new Error("Login succeeded but token missing from response");
    }

    // 👤 EXTRACT USER
    const user =
      res.data?.user ||
      res.data?.data?.user ||
      res.data?.customer ||
      res.data?.data?.customer ||
      {
        email: email.trim(),
        id: res.data?.user_id || res.data?.customer_id,
      };

    console.log("👤 User extracted:", user);

    // 🔐 STORE TOKEN (LOCALSTORAGE — OPTION A)
    localStorage.setItem("token", token);

    console.log("✅ Token saved in localStorage:", {
      tokenInLS: localStorage.getItem("token"),
    });

    // 🧠 STORE USER IN REDUX
    dispatch(
      loginSuccess({
        user,
        userType: "customer",
      })
    );

    // ✅ SAVE FOR REHYDRATION
localStorage.setItem("token", token);
localStorage.setItem("user", JSON.stringify(user));
localStorage.setItem("userType", "customer");
    console.log("✅ Redux updated");

    // 🧪 TEST PROTECTED API (OPTIONAL BUT GOOD)
    try {
      const testResponse = await api.get("/customer/settings");
      console.log("✅ Token works! Protected API response:", testResponse.data);
    } catch (apiError) {
      console.error("❌ Token test failed:", {
        status: apiError.response?.status,
        message: apiError.message,
      });
    }

    // If redirected from chat → go there
// 🔥 HANDLE CHAT INTENT REDIRECT
if (redirectPath?.startsWith("/chat-intent/company/")) {
  const companyId = redirectPath.split("/").pop();

  try {
    const res = await createCustomerConversation({
      is_group: false,
      participant_ids: [Number(companyId)],
    });

    const conversationId =
      res.data?.data?.id ||
      res.data?.conversation?.id ||
      res.data?.id;

    if (!conversationId) {
      console.error("Conversation ID missing after login", res.data);
      return;
    }

    navigate(`/customer-login/chat/${conversationId}`, { replace: true });
    return;
  } catch (err) {
    console.error("Chat creation after login failed", err);
  }
}

// ✅ Normal redirect (non-chat)
if (redirectPath) {
  navigate(redirectPath, { replace: true });
  return;
}


// Normal login flow
      setShowWelcome(true);

    showModernAlert("Successfully signed in!", "success");

  } catch (err) {
    console.error("❌ LOGIN ERROR:", {
      message: err.message,
      response: err.response?.data,
      status: err.response?.status,
    });

    if (err.response?.status === 401) {
      setError("Invalid email or password");
    } else if (err.response?.status === 422) {
      setError("Validation error");
    } else if (err.response?.status === 500) {
      setError("Server error. Please try again later.");
    } else {
      setError(err.message || "Login failed");
    }
  } finally {
    setLoading(false);
  }
};



// DEMO COMPANY LOGIN (NO API)
const handleCompanyLogin = async (e) => {
  e.preventDefault();
  if (loginType !== "company") return;

  setLoading(true);
  setError("");

  try {
    console.log("🧪 DEMO Company login:", {
      email: companyEmail.trim(),
      password: companyPassword.trim(),
    });

    // ⛔ Simple demo validation
    if (!companyEmail.trim() || !companyPassword.trim()) {
      throw new Error("Email and password are required");
    }

    // 🧪 Fake token
    const demoToken = "demo-company-token-123456";

    // 🧪 Fake company user
    const demoCompanyUser = {
      id: "demo-company-id",
      email: companyEmail.trim(),
      name: "Demo Company",
      isDemo: true,
    };

    // 🔐 SAVE TOKEN (same as real login)
    localStorage.setItem("token", demoToken);

    console.log("✅ Demo token saved:", demoToken);
    console.log("👤 Demo company user:", demoCompanyUser);

    // 🧠 UPDATE REDUX
    dispatch(
      loginSuccess({
        user: demoCompanyUser,
        userType: "company",
      })
    );

    // 🎉 UI
    setShowWelcome(true);
    showModernAlert("Demo company signed in successfully!", "success");

  } catch (err) {
    console.error("❌ DEMO COMPANY LOGIN ERROR:", err.message);
    setError(err.message || "Demo login failed");
  } finally {
    setLoading(false);
  }
};



  const handleSubmit = (e) => {
    if (loginType === "customer") {
      handleCustomerLogin(e);
    } else {
      handleCompanyLogin(e);
    }
  };

  const handleGoToDashboard = () => {
    if (auth.userType === "customer") {
      navigate("/customer-login");
    } else {
      navigate("/company-dashboard");
    }
  };

  // REAL LOGOUT with API call




  return (
    <>
      {/* Modern Alert - CENTERED */}
      <ModernAlert 
        message={alertMessage}
        show={showAlert}
        type={alertType}
      />

      {/* Welcome Page */}
      {showWelcome && auth.user && (
        <WelcomePage 
          user={auth.user}
          userType={auth.userType}
          onGoToDashboard={handleGoToDashboard}
          
        />
      )}

      {/* Main Login Form - Only show if not showing welcome page */}
      {!showWelcome && (
        <section className="min-h-[80vh] flex items-center justify-center bg-gradient-to-br from-gray-50 to-blue-50/30 py-16 px-4 overflow-x-hidden">
          <div className="w-full max-w-md">
            <div className="bg-white/80 backdrop-blur-sm rounded-3xl border border-white/20 shadow-2xl p-8">
              
              {/* Logo at top */}
              <div className="flex justify-center mb-8">
                <button 
                  onClick={() => navigate("/")}
                  className="hover:opacity-80 transition-all duration-300 transform hover:scale-105"
                >
                  <img 
                    src={logo} 
                    alt="Home" 
                    className="h-14 w-auto"
                  />
                </button>
              </div>

              {/* Success message for newly registered users */}
              {isRegistered && (
                <div className="mb-6 p-4 bg-gradient-to-r from-green-50 to-emerald-50 border border-green-200/50 text-green-700 rounded-2xl text-sm backdrop-blur-sm">
                  <div className="flex items-center">
                    <div className="w-8 h-8 bg-green-500 rounded-full flex items-center justify-center mr-3 shadow-sm">
                      <svg className="w-4 h-4 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="3" d="M5 13l4 4L19 7"></path>
                      </svg>
                    </div>
                    <span className="font-medium">Registration successful! Please sign in to continue.</span>
                  </div>
                </div>
              )}

              {/* Tabs */}
              <div className="flex justify-center mb-8 bg-gray-100/50 rounded-2xl p-1 backdrop-blur-sm">
                <button
                  onClick={() => setLoginType("customer")}
                  className={`w-1/2 py-3 rounded-xl font-medium transition-all duration-300 ${
                    loginType === "customer"
                      ? "bg-white text-blue-600 shadow-lg border border-white/50"
                      : "text-gray-500 hover:text-gray-700 hover:bg-white/30"
                  }`}
                >
                  Customer
                </button>

                <button
                  onClick={() => setLoginType("company")}
                  className={`w-1/2 py-3 rounded-xl font-medium transition-all duration-300 ${
                    loginType === "company"
                      ? "bg-white text-blue-600 shadow-lg border border-white/50"
                      : "text-gray-500 hover:text-gray-700 hover:bg-white/30"
                  }`}
                >
                  Business
                </button>
              </div>

              {/* Login Forms */}
              {loginType === "customer" ? (
                <form className="flex flex-col gap-5" onSubmit={handleSubmit}>
                  {error && (
                    <div className="p-4 bg-gradient-to-r from-red-50 to-pink-50 border border-red-200/50 text-red-700 rounded-2xl text-sm text-center backdrop-blur-sm">
                      <div className="flex items-center justify-center">
                        <div className="w-6 h-6 bg-red-500 rounded-full flex items-center justify-center mr-2">
                          <svg className="w-3 h-3 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="3" d="M6 18L18 6M6 6l12 12"></path>
                          </svg>
                        </div>
                        {error}
                      </div>
                    </div>
                  )}

                  <div className="space-y-4">
                    <input
                      type="email"
                      placeholder="Email address"
                      value={email}
                      onChange={(e) => setEmail(e.target.value)}
                      className="w-full px-4 py-4 rounded-2xl bg-white/50 border border-gray-200/50 text-sm focus:ring-2 focus:ring-blue-500/30 focus:border-blue-400 transition-all duration-300 backdrop-blur-sm placeholder-gray-500"
                      required
                    />

                    <input
                      type="password"
                      placeholder="Password"
                      value={password}
                      onChange={(e) => setPassword(e.target.value)}
                      className="w-full px-4 py-4 rounded-2xl bg-white/50 border border-gray-200/50 text-sm focus:ring-2 focus:ring-blue-500/30 focus:border-blue-400 transition-all duration-300 backdrop-blur-sm placeholder-gray-500"
                      required
                    />
                  </div>

                  <div className="flex justify-end items-center text-sm">
                    <Link
                      to="/forgot-password"
                      className="text-blue-600 hover:text-blue-800 font-medium transition-colors duration-200"
                    >
                      Forgot Password?
                    </Link>
                  </div>

                  <button
                    type="submit"
                    disabled={loading}
                    className="w-full bg-gradient-to-r from-blue-500 to-cyan-500 text-white py-4 rounded-2xl text-sm font-semibold hover:from-blue-600 hover:to-cyan-600 transition-all duration-300 transform hover:scale-[1.02] disabled:opacity-50 disabled:transform-none shadow-lg hover:shadow-xl"
                  >
                    {loading ? (
                      <div className="flex items-center justify-center">
                        <div className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin mr-2"></div>
                        Signing In...
                      </div>
                    ) : (
                      "Sign In"
                    )}
                  </button>
                </form>
              ) : (
                /* Company Login Form */
                <form className="flex flex-col gap-5" onSubmit={handleSubmit}>
                  {error && (
                    <div className="p-4 bg-gradient-to-r from-red-50 to-pink-50 border border-red-200/50 text-red-700 rounded-2xl text-sm text-center backdrop-blur-sm">
                      <div className="flex items-center justify-center">
                        <div className="w-6 h-6 bg-red-500 rounded-full flex items-center justify-center mr-2">
                          <svg className="w-3 h-3 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="3" d="M6 18L18 6M6 6l12 12"></path>
                          </svg>
                        </div>
                        {error}
                      </div>
                    </div>
                  )}

                  <div className="space-y-4">
                    <input
                      type="email"
                      placeholder="Company email address"
                      value={companyEmail}
                      onChange={(e) => setCompanyEmail(e.target.value)}
                      className="w-full px-4 py-4 rounded-2xl bg-white/50 border border-gray-200/50 text-sm focus:ring-2 focus:ring-blue-500/30 focus:border-blue-400 transition-all duration-300 backdrop-blur-sm placeholder-gray-500"
                      required
                    />

                    <input
                      type="password"
                      placeholder="Company password"
                      value={companyPassword}
                      onChange={(e) => setCompanyPassword(e.target.value)}
                      className="w-full px-4 py-4 rounded-2xl bg-white/50 border border-gray-200/50 text-sm focus:ring-2 focus:ring-blue-500/30 focus:border-blue-400 transition-all duration-300 backdrop-blur-sm placeholder-gray-500"
                      required
                    />
                  </div>

                  <div className="flex justify-end items-center text-sm">
                    <Link
                      to="/company-forgot-password"
                      className="text-blue-600 hover:text-blue-800 font-medium transition-colors duration-200"
                    >
                      Forgot Password?
                    </Link>
                  </div>

                  <button
                    type="submit"
                    disabled={loading}
                    className="w-full bg-gradient-to-r from-blue-500 to-cyan-500 text-white py-4 rounded-2xl text-sm font-semibold hover:from-blue-600 hover:to-cyan-600 transition-all duration-300 transform hover:scale-[1.02] disabled:opacity-50 disabled:transform-none shadow-lg hover:shadow-xl"
                  >
                    {loading ? (
                      <div className="flex items-center justify-center">
                        <div className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin mr-2"></div>
                        Signing In...
                      </div>
                    ) : (
                      "Sign In"
                    )}
                  </button>
                </form>
              )}

              {/* Registration link */}
              <p className="mt-8 text-center text-gray-600 text-sm">
              Don&apos;t have an account?{" "}
              {loginType === "customer" ? (
                <Link
                  to="/customer-register"
                  className="text-blue-600 font-semibold hover:text-blue-800 transition"
                >
                  Register
                </Link>
              ) : (
                <Link
                  to="/company-register"
                  className="text-blue-600 font-semibold hover:text-blue-800 transition"
                >
                  Register
                </Link>
              )}
            </p>

            </div>
          </div>
        </section>
      )}

      {/* Custom Animations */}
      <style>{`
        @keyframes scale-in {
          0% {
            transform: scale(0.8);
            opacity: 0;
          }
          100% {
            transform: scale(1);
            opacity: 1;
          }
        }
        
        .animate-scale-in {
          animation: scale-in 0.3s ease-out;
        }
      `}</style>
    </>
  );
}